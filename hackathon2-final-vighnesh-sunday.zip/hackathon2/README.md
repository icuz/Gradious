# everything in this project  is working fine. could have done better data validation. but i think it is fine for now. i will keep improving it.

# here is how to run this project:

1. use the sql file inside the `/sql` folder to create the database and tables.
2. make changes to `config/dataCon.js` file to match your database configuration.
3. run `npm install` command(if still some packages are still missing run `npm install express multer uuid sharp cors`).
4. run `node app.js` command.
6. run `index.html` file, which is inside `/static` folder
** inside the `index.html` we can click on `get all bills` button to get all the bills from the database. **
