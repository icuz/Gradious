class Stack {
    constructor() {
      this.items = [];
    }
  
    // Push
    push(element) {
      this.items.push(element);
    }
  
    // Pop
    pop() {
      if (this.isEmpty()) {
        return "Underflow";
      }
      return this.items.pop();
    }
  
    // Peek
    peek() {
      return this.items[this.items.length - 1];
    }
  
    // Check if the stack is empty
    isEmpty() {
      return this.items.length === 0;
    }
  
    // Get the size of the stack
    size() {
      return this.items.length;
    }
  
    // Clear the stack
    clear() {
      this.items = [];
    }
  
    // Print the stack elements
    printStack() {
      let str = "";
      for (let i = 0; i < this.items.length; i++) {
        str += this.items[i] + " ";
      }
      return str.trim(); // Remove trailing space
    }
  
    // Check if parentheses, braces, and brackets are balanced
    isBalanced(expression) {
      const openingSymbols = "([{";
      const closingSymbols = ")]}";
      const stack = new Stack();
  
      for (let i = 0; i < expression.length; i++) {
        let char = expression[i];
        if (openingSymbols.includes(char)) {
          stack.push(char);
        } else if (closingSymbols.includes(char)) {
          if (stack.isEmpty()) {
            return false;
          }
          let top = stack.pop();
          if (closingSymbols.indexOf(char) !== openingSymbols.indexOf(top)) {
            return false; // Mismatched symbols
          }
        }
      }
  
      return stack.isEmpty(); // All symbols matched if stack is empty
    }
    // Evaluate a postfix expression using a stack and return the converted expression
    evaluatePostfixExpression(expression) {
      const operators = "+-*/";
      const stack = new Stack();
      const infixStack = new Stack();

      for (let char of expression) {
        if (operators.includes(char)) {
          const operand2 = stack.pop();
          const operand1 = stack.pop();
          const infixOperand2 = infixStack.pop();
          const infixOperand1 = infixStack.pop();
          let result;
          switch (char) {
            case "+":
              result = operand1 + operand2;
              break;
            case "-":
              result = operand1 - operand2;
              break;
            case "*":
              result = operand1 * operand2;
              break;
            case "/":
              if (operand2 === 0) {
                throw new Error("Division by zero");
              }
              result = operand1 / operand2;
              break;
            default:
              throw new Error("Invalid operator");
          }
          stack.push(result);
          infixStack.push(`(${infixOperand1}${char}${infixOperand2})`);
        } else {
          // convert to numbers from string
          stack.push(parseFloat(char));
          infixStack.push(char);
        }
      }

      if (stack.size() !== 1) {
        throw new Error("Invalid postfix expression: Incorrect number of operands");
      }

      return {
        result: stack.pop(),
        infixExpression: infixStack.pop()
      };
    }
    // Convert an infix expression to postfix using a stack
    convertInfixToPostfix(expression) {
      const operators = "+-*/";
      const precedence = { "+": 1, "-": 1, "*": 2, "/": 2 };
      const stack = new Stack();
      let postfix = "";

      for (let char of expression) {
        if (char === "(") {
          stack.push(char);
        } else if (char === ")") {
          while (stack.peek() !== "(") {
            postfix += stack.pop();
          }
          stack.pop(); // Remove the "("
        } else if (operators.includes(char)) {
          while (!stack.isEmpty() && precedence[char] <= precedence[stack.peek()]) {
            postfix += stack.pop();
          }
          stack.push(char);
        } else {
          postfix += char;
        }
      }

      while (!stack.isEmpty()) {
        postfix += stack.pop();
      }

      return postfix;
    }
  }
  
// Create a new stack instance
const stack = new Stack();

// Test stack operations
console.log(stack.isEmpty());      // true
stack.push(10);
stack.push(20);
stack.push(30);
console.log(stack.printStack());  // 10 20 30
console.log(stack.peek());        // 30
console.log(stack.size());        // 3
console.log(stack.pop());         // 30
console.log(stack.printStack());  // 10 20

// Test balanced expression check
console.log(stack.isBalanced("{[(])}"));   // false
console.log(stack.isBalanced("{[()]}"));   // true

// Test postfix expression evaluation and conversion back to postfix

const input2 = "2+3*4";
const postfix2 = stack.convertInfixToPostfix(input2);
console.log(`${input2} is converted to ${postfix2}`); //234*+
const evaluation2 = stack.evaluatePostfixExpression(postfix2);
console.log(`${postfix2} is evaluated to ${evaluation2.result}`); // 234*+ is evaluated to 14
console.log("converted infix expression", evaluation2.infixExpression);
const postfixBack2 = stack.convertInfixToPostfix(evaluation2.infixExpression);
console.log("converted back to postfix", postfixBack2); // 234*+
console.log(" ");
const input3 = "3+5*2";
const postfix3 = stack.convertInfixToPostfix(input3);
console.log(`${input3} is converted to ${postfix3}`); //352*+
const evaluation3 = stack.evaluatePostfixExpression(postfix3);
console.log(`${postfix3} is evaluated to ${evaluation3.result}`); // 352*+ is evaluated to 13
console.log("converted infix expression", evaluation3.infixExpression);
const postfixBack3 = stack.convertInfixToPostfix(evaluation3.infixExpression);
console.log("converted back to postfix", postfixBack3); // 352*+
console.log(" ");
const input4 = "3*(4+5)";
const postfix4 = stack.convertInfixToPostfix(input4);
console.log(`${input4} is converted to ${postfix4}`); //345+*
const evaluation4 = stack.evaluatePostfixExpression(postfix4);
console.log(`${postfix4} is evaluated to ${evaluation4.result}`); // 345+* is evaluated to 27
console.log("converted infix expression", evaluation4.infixExpression);
const postfixBack4 = stack.convertInfixToPostfix(evaluation4.infixExpression);
console.log("converted back to postfix", postfixBack4); // 345+*
